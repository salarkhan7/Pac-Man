package pacman;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Pacman extends JFrame{

    public Pacman() {
        displayMenu();
        add(new Model());
    }
    private void displayMenu() {
        String[] options = { "Start Game", "Exit" };
        int choice = JOptionPane.showOptionDialog(this, "Welcome to Pacman!", "Menu",
                JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (choice == 1) {
            System.exit(0); // Exit the game if "Exit" is selected
        }
    }


    public static void main(String[] args) {
        Pacman pac = new Pacman();
        pac.setVisible(true);
        pac.setTitle("Pacman");
        pac.setSize(720,1280);
        pac.setDefaultCloseOperation(EXIT_ON_CLOSE);
        pac.setLocationRelativeTo(null);

    }

}
