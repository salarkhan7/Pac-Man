module Pacman {
    requires java.desktop;
}